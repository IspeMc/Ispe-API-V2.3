# AlwaysDay
**Plugin That Makes All Worlds Day Time.**

## Features
- [x] Make all worlds in day time
- [x] Can be used with other plugins

<b>Made with ❤ by Zinkil</b>
