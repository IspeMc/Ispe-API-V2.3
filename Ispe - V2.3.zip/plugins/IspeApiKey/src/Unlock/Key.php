<?php

namespace Unlock;

use pocketmine\plugin\PluginBase;

class Key extends PluginBase {

    public function onLoad(){
        $this->getLogger()->info("Unlock IspeApi...");
    }

    public function onEnable(){
        $this->getLogger()->info("Sucees Unlock IspeApi");
    }
}