<?php

namespace Ispe\Commands;

use pocketmine\command\CommandSender;
use pocketmine\Player;
use Ispe\IspeV2;
use pocketmine\command\PluginCommand;

class Gamemode extends PluginCommand {

    /**
     * @var Core
     */
    private $plugin;

    public function __construct(IspeV2 $plugin) {
        parent::__construct("gamemode", $plugin);
        $this->setDescription("Change your gamemode or that of a player");
        $this->setPermission("gamemode.cmd");
        $this->setAliases(["gm"]);
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {
        if(!isset($args[0])) {
            return $sender->sendMessage("§l§a» §r§cUsage: /gamemode (0/1/2/3) (name) !");
        }

        switch ($args[0]) {
            case 0:
                $gamemode = "生存"; break;
            case 1:
                $gamemode = "创造"; break;
            case 2:
                $gamemode = "冒险"; break;
            case 3:
                $gamemode = "观察者"; break;
            default:
                return $sender->sendMessage("§l§a» §r§cUsage: /gamemode (0/1/2/3) (name) !");
        }

        if ((!$sender->hasPermission("gamemode.cmd"))) {
            return $sender->sendMessage("§l§eISPE §8» §c你没有权限使用这个指令！");
        }

        if(isset($args[1])) {
            if(!$this->plugin->getServer()->getPlayer($args[1]))$sender->sendMessage("§l§eISPE §8»§c " . $args[1] . "§c没有上线！");
            $targetPlayer = $this->plugin->getServer()->getPlayer($args[1]);
            $targetPlayer->setGamemode((int)$args[0]);
            $targetPlayer->sendMessage("§l§eISPE §8» §a你现在的模式是{$gamemode}！");
            $sender->sendMessage("§l§a» §r§fYou put §a" . $targetPlayer->getName() . "§f in §a{$gamemode} Mod §f!");
        } else if (!$sender instanceof Player) {
                return $sender->sendMessage("§l§eISPE §8» §c你不能使用这个指令在控制台！");
        } else {
            $sender->setGamemode((int)$args[0]);
            $sender->sendMessage("§l§a» §r§fYou are now in §a{$gamemode} Mod §f!");
        }
        return true;
    }
}