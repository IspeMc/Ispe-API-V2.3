<?php

namespace Ispe\Commands;

use Ispe\IspeV2;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;

class Spawn extends PluginCommand {

    private $plugin;

    public function __construct(IspeV2 $plugin) {
        parent::__construct("spawn", $plugin);
        $this->setDescription("返回出生点");
        $this->setAliases(["lobby", "hub", "back"]);
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, $label, array $args) {
        if($sender instanceof Player) {
            $sender->teleport($this->plugin->getServer()->getDefaultLevel()->getSafeSpawn());
            $sender->removeAllEffects();
            $sender->setHealth(20);
            $sender->setMaxHealth(20);
            $sender->setScale(1.0);
            $sender->setGamemode(2);
            $sender->setFood(20);
            $sender->getArmorInventory()->clearAll();
            $sender->getInventory()->clearAll();
            $sender->setAllowFlight(false);
            $sender->sendTitle("§ePlay§b Ispe§f - §aV2");
            $this->plugin->getArticulos()->give($sender);
        }
    }

}