<?php

namespace Ispe\Commands;

use Ispe\IspeV2;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;

class Unmute extends PluginCommand {

    private $plugin;

    public function __construct(IspeV2 $plugin) {
        parent::__construct("unmute", $plugin);
        $this->setDescription("Unmute a player");
        $this->setPermission("unmute.cmd");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {
        if (!$sender->hasPermission("unmute.cmd")) {
            return $sender->sendMessage("§l§eISPE §8» §c你没有权限使用这个指令！");
        }

        if (!isset($args[0])) {
            return $sender->sendMessage("§l§a» §r§cUsage: /unmute (name) !");
        }

        if ($this->plugin->getServer()->getPlayer($args[0]) == true) {
            $target = $this->plugin->getServer()->getPlayer($args[0]);
            $targetName = $target->getName();
            if ($this->plugin->getSanctionAPI()->isMuted($targetName) == false) {
                return $sender->sendMessage("§l§a» §r§cThis player is not muted !");
            }
            $this->plugin->getSanctionAPI()->DeleteMute($targetName);
            $target->sendMessage("§l§a» §r§fYou have been unmute !");
            $sender->sendMessage("§l§a» §r§fYou have unmuted §a{$targetName}§f !");
        } else {
            $targetName = strtolower($args[0]);
            if ($this->plugin->getSanctionAPI()->isMuted($targetName) == false) {
                return $sender->sendMessage("§l§a» §r§cThis player is not muted !");
            }
            $this->plugin->getSanctionAPI()->DeleteMute($targetName);
            $sender->sendMessage("§l§a» §r§fYou have unmuted §a{$targetName}§f !");
        }
        return true;
    }
}
