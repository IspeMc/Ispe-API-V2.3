<?php

namespace Ispe\Commands;

use Ispe\IspeV2;
use pocketmine\command\PluginCommand;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\plugin\Plugin;

class Say extends PluginCommand {

    protected $core;

    public function __construct(IspeV2 $core) {
        parent::__construct("say", $core);
        $this->setDescription("Write a announcement");
        $this->setPermission("say.cmd");
        $this->setAliases(["announce"]);
        $this->core = $core;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {
        if ($sender instanceof Player) {
            if ($sender->hasPermission("say.cmd")) {
                $this->core->getServer()->broadcastMessage("§a{$sender->getName()} §8»§f " . implode(" ", $args));
            } else {
                $sender->sendMessage("§l§eISPE §8» §c你没有权限使用这个指令！");
            }
        } else {
            $this->core->getServer()->broadcastMessage("§d[Server]§f " . implode(" ", $args));
        }
        return true;
    }

    public function getPlugin(): Plugin {
        return $this->core;
    }
}