<?php

namespace Ispe\Commands;

use Ispe\IspeV2;
use pocketmine\command\PluginCommand;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class Ping extends PluginCommand {

    private $plugin;

    public function __construct(IspeV2 $plugin){
        parent::__construct("ping", $plugin);
        $this->setDescription("你的延迟");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args){
        if ($sender instanceof Player) {
            $ping = $sender->getPing();

            if (!isset($args[0])) {
                if ($ping < 100) {
                    $ping = "§a{$ping}";
                }
                if ($ping >= 100 and $ping < 300) {
                    $ping = "§6{$ping}";
                }
                if ($ping >= 300) {
                    $ping = "§c{$ping}";
                }
                $sender->sendMessage("§l§eISPE §8» §a你的延迟是§b{$ping}§a！");
            } else if ($this->plugin->getServer()->getPlayer($args[0]) instanceof Player) {
                $pinger = $this->plugin->getServer()->getPlayer($args[0]);
                $ping = $pinger->getPing();
                if($ping < 100) {
                    $ping = "§a{$ping}";
                }
                if($ping >= 100 and $ping < 300) {
                    $ping = "§6{$ping}";
                }
                if($ping >= 300) {
                    $ping = "§c{$ping}";
                }
                $sender->sendMessage("§l§a» §r§a{$pinger->getName()} §fcurrently has {$ping} §f!");
            } else {
                $pingerName = $args[0];
                $sender->sendMessage("§l§eISPE §8» §c{$pingerName} 没有在服务器内！");
            }
        } else {
            $sender->sendMessage("Run In Game !!");
        }
        return true;
    }
}