<?php

namespace Ispe\Commands;

use Ispe\IspeV2;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\utils\TextFormat;

class TPS extends PluginCommand {

    private $plugin;

    public function __construct(IspeV2 $plugin) {
        parent::__construct("tps", $plugin);
        $this->setDescription("查看服务器 TPS");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {
        $tpsColor = TextFormat::GREEN;
        $server = Core::getInstance()->getServer();
        if ($server->getTicksPerSecond() < 17) {
            $tpsColor = TextFormat::GOLD;
        } elseif ($server->getTicksPerSecond() < 12) {
            $tpsColor = TextFormat::RED;
        }

        $sender->sendMessage("§l§eISPE §8» §2§f当前 TPS: {$tpsColor}{$server->getTicksPerSecond()} ({$server->getTickUsage()}%)");
        $sender->sendMessage("§l§eISPE §8» §e平均 TPS: {$tpsColor}{$server->getTicksPerSecondAverage()} ({$server->getTickUsageAverage()}%)");
        return true;
    }
}