<?php

namespace Ispe\Commands;

use Ispe\IspeV2;
use pocketmine\command\PluginCommand;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class Online extends PluginCommand {

    private $plugin;

    public function __construct(IspeV2 $plugin) {
        parent::__construct("list", $plugin);
        $this->setDescription("服务器玩家");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {
        $playerNames = array_map(function(Player $player) : string {
            return $player->getName();
        }, array_filter($sender->getServer()->getOnlinePlayers(), function(Player $player) use ($sender) : bool {
            return $player->isOnline() and (!($sender instanceof Player) or $sender->canSee($player));
        }));

        sort($playerNames, SORT_STRING);
        $count = count($playerNames);
        $sender->sendMessage("§l§eISPE §8» §b服务器所有玩家：§e(§a{$count}/{$sender->getServer()->getMaxPlayers()}§e)");
        return true;
    }
}