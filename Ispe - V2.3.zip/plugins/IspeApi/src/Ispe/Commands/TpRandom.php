<?php

namespace Ispe\Commands;

use Ispe\IspeV2;
use pocketmine\command\PluginCommand;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class TpRandom extends PluginCommand {

    private $plugin;

    public function __construct(IspeV2 $plugin) {
        parent::__construct("tpr", $plugin);
        $this->setDescription("Randomly teleport to a player");
        $this->setPermission("tpr.cmd");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {
        $players = $this->plugin->getServer()->getOnlinePlayers();
        if (!($sender instanceof Player)) {
            return true;
        }

        if (!($sender->hasPermission("tpr.cmd"))) {
            return $sender->sendMessage("§l§eISPE §8» §c你没有权限使用这个指令！");
        }

        if (count($players) <= 1) {
            return $sender->sendMessage("§l§a» §r§cNo player is connected on the server !");
        }

        $random = $players[array_rand($players)];
        while ($random === $sender) {
            $random = $players[array_rand($players)];
        }

        $sender->teleport($random);
        $sender->sendMessage("§l§a» §r§fYou have been telephoned to §a{$random->getName()}§f !");
        return true;
    }

}