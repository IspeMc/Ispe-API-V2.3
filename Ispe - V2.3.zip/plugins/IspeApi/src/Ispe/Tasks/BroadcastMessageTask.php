<?php

namespace Ispe\Tasks;

use Ispe\IspeV2;
use pocketmine\scheduler\Task;

class BroadcastMessageTask extends Task {

    public $plugin;
    private static $message = [
        "§l§eISPE §8» §a我们有Gapple, Sumo, Stick, Nodebuff, Bow 五个模式任你选择！"];
    private static $old = 0;

    public function __construct(IspeV2 $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun(int $tick){
        $this->plugin->getServer()->broadcastMessage(self::$message[self::$old]);
        self::$old++;
        if(self::$old > count(self::$message)-1)self::$old = 0;
    }

}