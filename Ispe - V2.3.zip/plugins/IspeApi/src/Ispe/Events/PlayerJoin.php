<?php

namespace Ispe\Events;

use Ispe\IspeV2;
use Ispe\Tasks\KickTask;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\Player;

class PlayerJoin implements Listener {

    private $plugin;

    public function __construct(IspeV2 $plugin) {
        $this->plugin = $plugin;
    }

    public function PlayerJoin(PlayerJoinEvent $event) {
        if ($event->getPlayer() instanceof Player) {
            $player = $event->getPlayer();
            $name = $player->getName();
            $player->sendMessage("§l§b本服更新:\n§l§a添加了Bow模式");
            $player->sendTitle("§ePlay§b Ispe§f - §aV2");
            $event->setJoinMessage("");
            $this->plugin->getServer()->broadcastMessage("§6[§a+§6] §a{$name}");
        }
    }
}