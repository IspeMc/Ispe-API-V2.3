<?php

namespace Ispe\Events;

use Ispe\IspeV2;
use Ispe\CustomPlayer;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerCreationEvent;

class PlayerCreation implements Listener {

    private $plugin;

    public function __construct(IspeV2 $plugin) {
        $this->plugin = $plugin;
    }

    public function onPlayer(PlayerCreationEvent $event) : void {
        $event->setPlayerClass(CustomPlayer::class);
    }
}