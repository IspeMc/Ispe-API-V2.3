<?php

namespace Ispe\Events;

use Ispe\IspeV2;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerExhaustEvent;

class PlayerExhaust implements Listener {

    private $plugin;

    public function __construct(IspeV2 $plugin) {
        $this->plugin = $plugin;
    }

    public function onExhaust(PlayerExhaustEvent $event) {
        $event->getPlayer()->setFood(20);
    }

}