<?php

namespace Ispe\Events;

use Ispe\IspeV2;
use pocketmine\event\Listener;
use pocketmine\event\server\CommandEvent;

class CommandPreprocess implements Listener {

    private $plugin;

    public function __construct(IspeV2 $plugin) {
        $this->plugin = $plugin;
    }

    public function onCommandEvent(CommandEvent $event) : void {
        $args = explode(" ", $event->getCommand());
        $command = strtolower(array_shift($args));
        if (!$args) {
            $event->setCommand($command);
            return;
        } $event->setCommand($command . " " . join(" ", $args));
    }

}