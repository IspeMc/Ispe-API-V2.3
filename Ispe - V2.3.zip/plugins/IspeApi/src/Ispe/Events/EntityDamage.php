<?php

namespace Ispe\Events;

use Ispe\IspeV2;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;

class EntityDamage implements Listener {

    private $plugin;

    public function __construct(IspeV2 $plugin) {
        $this->plugin = $plugin;
    }

    public function e_damage(EntityDamageEvent $event){
        if ($event->getCause()===EntityDamageEvent::CAUSE_FALL) {
            $event->setCancelled();
        }
    }

}