<?php

namespace Ispe\Events;

use Ispe\IspeV2;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\Listener;

class PlayerDropItem implements Listener {

    private $plugin;

    public function __construct(IspeV2 $plugin) {
        $this->plugin = $plugin;
    }

    public function onDrop(PlayerDropItemEvent $event) {
        $item = $event->getItem();
        $player = $event->getPlayer();
        $event->setCancelled();
    }

}