<?php

namespace Ispe\Events;

use Ispe\IspeV2;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerPreLoginEvent;

class PlayerPreLogin implements Listener {

    private $plugin;

    public function __construct(IspeV2 $plugin) {
        $this->plugin = $plugin;
    }

    public function onPlayerPreLogin(PlayerPreLoginEvent $event) {
        $player = $event->getPlayer();
        if (!$this->plugin->getServer()->isWhitelisted($player->getName())) {
            $player->close("", "Server is whitelisted");
            $event->setCancelled(true);
            return;
        }
    }

}