<?php

namespace Ispe\Events;

use Ispe\IspeV2;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;

class PlayerQuit implements Listener {

    private $plugin;

    public function __construct(IspeV2 $plugin) {
        $this->plugin = $plugin;
    }

    public function PlayerQuit(PlayerQuitEvent $event) {
        $player = $event->getPlayer();
        $name = $player->getName();
        $event->setQuitMessage("");
        $this->plugin->getServer()->broadcastMessage("§6[§c-§6] §c{$name}");
    }

}