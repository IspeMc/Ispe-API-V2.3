<?php

namespace Ispe\Game;

use Ispe\Events\PlayerJoin;
use Ispe\Form\FormUI;
use Ispe\Form\SimpleForm;
use Ispe\IspeV2;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat as TE;

class GameApi {

    use FormUI;
    private $plugin;

    public function __construct(IspeV2 $plugin) {
        $this->plugin = $plugin;
    }

    public function give($player) {
        $player->getInventory()->clearAll();
        $player->getArmorInventory()->clearAll();
        $player->getInventory()->setItem(4, Item::get(267, 0, 1)->setCustomName("§r§aFree For All§7 [使用]"));
    }

    public function GameApiCore($player) : SimpleForm {
        $form = new SimpleForm(function (Player $player, $data = null) : void {
            $result = $data;
            if ($result === null) {
                return;
            }
            switch ($data) {
                case "gapple":
                    $player->teleport(Server ::getInstance()->getLevelByName('gapple')->getSafeSpawn());
                    $player->getArmorInventory()->clearAll();
                    $player->removeAllEffects();
                    $player->getInventory()->clearAll();
                    $player->setHealth(20);
                    $player->setFood(20);
                    $player->setSaturation(20);

                    $helmet = Item::get(Item::DIAMOND_HELMET, 0, 1);
                    $helmet->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
                    $player->getArmorInventory()->setHelmet($helmet);

                    $chestplate = Item::get(Item::DIAMOND_CHESTPLATE, 0, 1);
                    $chestplate->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
                    $player->getArmorInventory()->setChestplate($chestplate);

                    $leggings = Item::get(Item::DIAMOND_LEGGINGS, 0, 1);
                    $leggings->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
                    $player->getArmorInventory()->setLeggings($leggings);

                    $boots = Item::get(Item::DIAMOND_BOOTS, 0, 1);
                    $boots->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::PROTECTION), 4));
                    $player->getArmorInventory()->setBoots($boots);

                    $sword = Item::get(Item::DIAMOND_SWORD, 0, 1);
                    $sword->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::SHARPNESS), 5));
                    $player->getInventory()->setItem(0, ($sword));

                    $apple = Item::get(Item::GOLDEN_APPLE, 0, 10);
                    $player->getInventory()->setItem(1, ($apple));
                    break;
                case "nodebuff":
                    $player->teleport(Server::getInstance()->getLevelByName('nodebuff')->getSafeSpawn());
                    $player->getArmorInventory()->clearAll();
                    $player->removeAllEffects();
                    $player->getInventory()->clearAll();
                    $player->setHealth(20);
                    $player->setFood(20);
                    $player->setSaturation(20);

                    $helmet1 = Item::get(Item::DIAMOND_HELMET, 0, 1);
                    $helmet1->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                    $player->getArmorInventory()->setHelmet($helmet1);

                    $chestplate1 = Item::get(Item::DIAMOND_CHESTPLATE, 0, 1);
                    $chestplate1->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                    $player->getArmorInventory()->setChestplate($chestplate1);

                    $leggings1 = Item::get(Item::DIAMOND_LEGGINGS, 0, 1);
                    $leggings1->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                    $player->getArmorInventory()->setLeggings($leggings1);

                    $boots1 = Item::get(Item::DIAMOND_BOOTS, 0, 1);
                    $boots1->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                    $player->getArmorInventory()->setBoots($boots1);

                    $sword1 = Item::get(Item::DIAMOND_SWORD, 0, 1);
                    $sword1->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                    $player->getInventory()->setItem(0, ($sword1));

                    $pearl1 = Item::get(Item::ENDER_PEARL, 0, 16);
                    $player->getInventory()->setItem(1, ($pearl1));

                    $pot1 = Item::get(Item::SPLASH_POTION, 22, 64);
                    $player->getInventory()->addItem($pot1);

                    $effect1 = new EffectInstance(Effect::getEffect(Effect::SPEED));
                    $effect1->setVisible(false);
                    $effect1->setAmplifier(0);
                    $effect1->setDuration(100 * 100 * 100);
                    $player->addEffect($effect1);
                    break;
                case "hivesumo":
                    $player->teleport(Server::getInstance()->getLevelByName('hivesumo')->getSafeSpawn());
                    $player->getArmorInventory()->clearAll();
                    $player->removeAllEffects();
                    $player->getInventory()->clearAll();
                    $player->setHealth(20);
                    $player->setFood(20);
                    $player->setSaturation(20);

                    $effect2 = new EffectInstance(Effect::getEffect(Effect::RESISTANCE));
                    $effect2->setVisible(false);
                    $effect2->setAmplifier(1);
                    $effect2->setDuration(100 * 100 * 100);
                    $player->addEffect($effect2);
                    break;
                case "stick":
                    $player->teleport(Server::getInstance()->getLevelByName('stick')->getSafeSpawn());
                    $player->getArmorInventory()->clearAll();
                    $player->removeAllEffects();
                    $player->getInventory()->clearAll();
                    $player->setHealth(20);
                    $player->setFood(20);
                    $player->setSaturation(20);

                    $effect3 = new EffectInstance(Effect::getEffect(Effect::RESISTANCE));
                    $effect3->setVisible(false);
                    $effect3->setAmplifier(2);
                    $effect3->setDuration(100 * 100 * 100);
                    $player->addEffect($effect3);

                    $apple = Item::get(Item::GOLDEN_APPLE, 0, 5);
                    $player->getInventory()->setItem(1, ($apple));

                    $stick = Item::get(Item::STICK, 0, 1);
                    $stick->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::KNOCKBACK), 2));
                    $player->getInventory()->setItem(0, ($stick));
                    break;
                case "bow":
                    $player->teleport(Server::getInstance()->getLevelByName('bow')->getSafeSpawn());
                    $player->getArmorInventory()->clearAll();
                    $player->removeAllEffects();
                    $player->getInventory()->clearAll();
                    $player->setHealth(20);
                    $player->setFood(20);
                    $player->setSaturation(20);

                    $effect4 = new EffectInstance(Effect::getEffect(Effect::WEAKNESS));
                    $effect4->setVisible(false);
                    $effect4->setAmplifier(1);
                    $effect4->setDuration(100 * 100 * 100);
                    $player->addEffect($effect4);

                    $chestplate2 = Item::get(Item::DIAMOND_CHESTPLATE, 0, 1);
                    $chestplate2->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::UNBREAKING), 3));
                    $player->getArmorInventory()->setChestplate($chestplate2);
                    
                    $bow = Item::get(Item::BOW, 0, 1);
                    $bow->addEnchantment(new EnchantmentInstance(Enchantment::getEnchantment(Enchantment::INFINITY), 1));
                    $player->getInventory()->setItem(0, ($bow));

                    $apple1 = Item::get(Item::GOLDEN_APPLE, 1, 10);
                    $player->getInventory()->setItem(1, ($apple1));

                    $arrow = Item::get(Item::ARROW, 0, 1);
                    $player->getInventory()->setItem(2, ($arrow));
                    break;
            }
        });

        $nodebuff = $this->plugin->getServer()->getLevelByName("nodebuff");
        $gapple = $this->plugin->getServer()->getLevelByName("gapple");
        $hivesumo = $this->plugin->getServer()->getLevelByName("hivesumo");
        $stick = $this->plugin->getServer()->getLevelByName("stick");
        $bow = $this->plugin->getServer()->getLevelByName("bow");

        if (!$this->plugin->getServer()->isLevelLoaded("nodebuff")) {
            $count1 = "§cArena close";
            $c1 = "offline";
        } else {
            $totalnodebuff = count($nodebuff->getPlayers());
            $count1 = "§l§8玩家: " . $totalnodebuff;
            $c1 = "nodebuff";
        }
        if (!$this->plugin->getServer()->isLevelLoaded("gapple")) {
            $count2 = "§cArena close";
            $c2 = "offline";
        } else {
            $totalgapple = count($gapple->getPlayers());
            $count2 = "§l§8玩家: " . $totalgapple;
            $c2 = "gapple";
        }
        if (!$this->plugin->getServer()->isLevelLoaded("hivesumo")) {
            $count4 = "§cArena close";
            $c4 = "offline";
        } else {
            $count4 = "§l§8玩家: " . count($hivesumo->getPlayers());
            $c4 = "hivesumo";
        }
        if (!$this->plugin->getServer()->isLevelLoaded("stick")) {
            $count5 = "§cArena Close";
            $c5 = "offline";
        } else {
            $count5 = "§l§8玩家: " . count($stick->getPlayers());
            $c5 = "stick";
        }
        if (!$this->plugin->getServer()->isLevelLoaded("bow")) {
            $count6 = "§cArena Close";
            $c6 = "offline";
        } else {
            $count6 = "§l§8玩家: " . count($bow->getPlayers());
            $c6 = "bow";
        }

        $form -> setTitle("§l模式");
        $form -> setContent("§a选择:");
        $form -> addButton("Gapple\n" . $count2, 0, "textures/items/apple_golden.png", $c2);
        $form -> addButton("Nodebuff\n" . $count1, 0, "textures/items/potion_bottle_splash_saturation.png", $c1);
        $form -> addButton("Sumo\n" . $count4, 0, "textures/items/feather.png", $c4);
        $form -> addButton("Stick\n" . $count5, 0, "textures/items/stick.png", $c5);
        $form -> addButton("Bow\n" . $count6, 0, "textures/items/bow_standby.png", $c6);
        $form ->addButton("§l§c关闭", 0, "textures/ui/realms_red_x.png");
        $form -> sendToPlayer($player);
        return $form;
    }
}