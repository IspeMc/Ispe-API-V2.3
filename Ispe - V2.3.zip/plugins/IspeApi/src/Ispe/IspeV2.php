<?php

namespace Ispe;

use Ispe\API\{SelectAPI, ServerAPI};
use Ispe\Commands\{Gamemode, Kick, KickAll, Knockback, Mute, Mutelist, Online, Ping, Say, Size, Spawn, Tell, TpRandom, TPS, Unmute};
use Ispe\Entity\{EnderPearl, SplashPotion};
use Ispe\Events\{BlockBreak, CommandPreprocess, EntityDamage, PlayerCreation, PlayerDeath, PlayerDropItem, PlayerExhaust, PlayerInteract, PlayerJoin, PlayerPreLogin, PlayerQuit};
use Ispe\Form\FormUI;
use Ispe\Game\GameApi;
use Ispe\Selector\{SelectAllPlayers, SelectRandomPlayers};
use Ispe\Tasks\{BorderTask, BroadcastMessageTask, ParticleTask};
use pocketmine\command\Command;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\entity\Entity;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class IspeV2 extends PluginBase implements Listener {

    /**
     * @var Config
     */

    use FormUI;
    public $red = array();
    public $green = array();
    public $blue = array();
    public static $cooldown;
    public static $data;
    private static $config;
    private static $instance;

    public function onEnable() {
        $this->getLogger()->info("
        ---     -------       |-------|       |--------
         |      |             |       |       | 
         |      |             |       |       |
         |      -------       |-------|       |--------
         |            |       |               |
         |            |       |               |
        ---     -------       |               |--------");
        $this->getResource("config.yml");
        $this->saveResource("cooldown.yml");
        $this->saveDefaultConfig();
        @mkdir($this->getDataFolder());

        Item::initCreativeItems();
        SelectAPI::registerSelector(new SelectAllPlayers());
        SelectAPI::registerSelector(new SelectRandomPlayers());
        Entity::registerEntity(SplashPotion::class, false, ['ThrownPotion', 'minecraft:potion', 'thrownpotion']);
        Entity::registerEntity(EnderPearl::class, false, ['ThrownEnderpearl', 'minecraft:ender_pearl']);
        for($i = 37; $i <= 42; $i++) {
            Item::removeCreativeItem(Item::get(Item::SPLASH_POTION, $i));
        }

        $this->getScheduler()->scheduleRepeatingTask(new ParticleTask($this), 10);
        $this->getScheduler()->scheduleRepeatingTask(new BorderTask($this), 20*5);
        $this->getScheduler()->scheduleRepeatingTask(new BroadcastMessageTask($this), 10000);
        $this->initCommands();
        $this->initEvents();
        if (!file_exists($this->getDataFolder()."knockback.yml")) {
            $this->saveResource('knockback.yml');
        }

        self::$config = new Config($this->getDataFolder()."cooldown.yml", Config::YAML);
        self::$data = new Config($this->getDataFolder() . "knockback.yml", Config::YAML);
        self::$instance = $this;

        $this->getServer()->loadLevel("lobby");
        $this->getServer()->loadLevel("gapple");
        $this->getServer()->loadLevel("nodebuff");
        $this->getServer()->loadLevel("hivesumo");
        $this->getServer()->loadLevel("stick");
        $this->getServer()->loadLevel("bow");
    }

    public function onDisable() {
        foreach($this->getServer()->getOnlinePlayers() as $players) {
            $players->kick("§l§eISPE §8» §c服务器已关闭/重启", false);
        }
    }

    public function onJoin(PlayerJoinEvent $event) {
        $player = $event->getPlayer();
        $lvl = $player->getLevel();
        $player->teleport($this->getServer()->getDefaultLevel()->getSafeSpawn());
        $player->setGamemode(2);
        $player->setHealth(20);
        $player->setFood(20);
        $player->setMaxHealth(20);
        $player->setScale(1);
        $player->setImmobile(false);
        $player->removeAllEffects();
        $this->getArticulos()->give($player);
    }

    public function onQuit(PlayerQuitEvent $event) {
        $player = $event->getPlayer();
        $player->getInventory()->clearAll();
        $player->getArmorInventory()->clearAll();
        $lvl = $player->getLevel();
    }

    public function onRespawn(PlayerRespawnEvent $event) {
        $player = $event->getPlayer();
        $player->teleport($this->getServer()->getDefaultLevel()->getSafeSpawn());
        $player->setGamemode(2);
        $player->setHealth(20);
        $player->setFood(20);
        $player->setMaxHealth(20);
        $player->setScale(1);
        $player->setImmobile(false);
        $player->removeAllEffects();
        $player->getInventory()->clearAll();
        $player->getArmorInventory()->clearAll();
        $player->setAllowFlight(false);
        $this->getArticulos()->give($player);
    }

    public function onInteract(PlayerInteractEvent $event) {
        $player = $event->getPlayer();
        $item = $player->getInventory()->getItemInHand();
        if (isset(self::$cooldown[$player->getName()]) and self::$cooldown[$player->getName()] - time() > 0) {
            return;
        }

        if (!$event->getAction() == $event::RIGHT_CLICK_BLOCK and !$event->getAction() == $event::RIGHT_CLICK_AIR) {
            return;
        }

        self::$cooldown[$player->getName()] = time()+1;
        if ($item->getName() == "§r§aFree For All§7 [使用]") {
            $this->getArticulos()->GameApiCore($player);
        }
    }

    private function registerCommand(Command $cmd) : void {
        $this->getServer()->getCommandMap()->register($cmd->getName(), $cmd);
    }

    private function unregisterCommand(string $name) : void {
        $map = $this->getServer()->getCommandMap();
        $cmd = $map->getCommand($name);
        if($cmd !== null) {
            $this->getServer()->getCommandMap()->unregister($cmd);
        }
    }

    private function initCommands() : void {
        $cmdunregister = ["mixer", "?", "help", "tps", "w", "tps", "msg", "ppinfo", "scorehud", "checkperm", "seed", "save-all", "save-on", "save-off", "particle", "difficulty", "dumpmemory",
            "defaultgamemode", "tell", "list", "me", "plugins", "version", "say", "kick", "gamemode"];
        foreach ($cmdunregister as $unregister) {
            $this->unregisterCommand($unregister);
        }

        $cmdregister = [new Size($this), new Online($this), new Say($this), new Mute($this), new TPS($this), new KickAll($this),
            new TpRandom($this), new Mutelist($this), new Ping($this), new Kick($this), new Gamemode($this), new Unmute($this), 
            new Knockback($this), new Spawn($this)];
        foreach ($cmdregister as $register) {
            $this->registerCommand($register);
        }
    }

    private function registerEvent($event) : void {
        $this->getServer()->getPluginManager()->registerEvents($event, $this);
    }

    private function initEvents() : void {
        $events = [$this, new PlayerCreation($this), new PlayerDeath($this),
            new PlayerJoin($this), new PlayerPreLogin($this), new PlayerExhaust($this), new PlayerInteract($this),
            new EntityDamage($this), new BlockBreak($this), new PlayerDropItem($this),
            new CommandPreprocess($this), new PlayerQuit($this)];
        foreach($events as $event){
            $this->registerEvent($event);
        }
    }

    private function registerItem($item, $truefalse) : void {
        ItemFactory::registerItem($item, $truefalse);
    }

    private function initItems() : void {
        $items = new Items\EnderPearl();
        foreach($items as $item) {
            $this->registerItem($item, true);
        }
    }

    public static function getInstance() : IspeV2 {
        return self::$instance;
    }

    public function getArticulos() : GameApi {
        return new GameApi($this);
    }

    public function removeTask($id) {
        $this->getScheduler()->cancelTask($id);
    }

    public function getServerAPI() : ServerAPI {
        return new ServerAPI($this);
    }
}