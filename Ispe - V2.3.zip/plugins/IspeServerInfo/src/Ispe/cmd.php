<?php

namespace Ispe;

use pocketmine\plugin\PluginBase;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\event\Listener;

use pocketmine\command\{Command, CommandSender};

class cmd extends PluginBase implements Listener {

    public function onEnable(){
        $this->getLogger()->info("");
    }

    public function onCommand(CommandSender $sender, Command $cmd, String $label, Array $args):bool{

        switch($cmd->getName()){
            case "info":
                $sender->sendMessage("§l§eIspe §f- §b服务器资讯\n§l§gDiscord: §aSoon\n§l§gYouTube:§a @mcispe1234");
        }
    return true;
    }
}